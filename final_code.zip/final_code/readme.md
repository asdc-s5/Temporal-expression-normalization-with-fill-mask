Download the annotador project from https://github.com/mnavasloro/Annotador
Copy and paste "Main.java" in "/Users/asdc/Desktop/Annotador-master/annotador-core/src/main/java/oeg/tagger/main"
Copy and paste "AnnotadorStandard.java" in  "/Users/asdc/Desktop/Annotador-master/annotador-core/src/main/java/oeg/tagger/core/time/tictag"

Execute "timex_normalization.sh" like ./ timex_normalization.sh "2001-10-25" "DATE" "Yesterday"

Due to space restrictions we cannot atatch the model to perform predictions. And due to anonymity restrictions we cannot provide a huggingface link.